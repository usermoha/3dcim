<!-- ================================================================= -->
<!-- ================================================================= -->
<!-- ============ By Mohammed Cha 2023 : Re-skinning GRP ============= -->
<!-- ================================================================= -->
<!-- ================================================================= -->

<?php  

$Re_skinning_Grp_uri = 'https://www.re-skinning.com/cpa/landing6'; // Website Link
$Re_skinning_Grp_wname = 'Movies'; // Website  Title
$Re_skinning_Grp_descrip = 'Free Movies'; // Website Description

$Re_skinning_Grp_adbluemedia_it = '1444147';  // AdBlueMedia IT
$Re_skinning_Grp_adbluemedia_key = 'e619c';  // AdBlueMedia KEY

$Re_skinning_Grp_ImdbApi = 'b7cd3340a794e5a2f35e3abb820b497f'; // Themoviedb API

$Re_skinning_Grp_video_mp4 = 'https://cdn.jsdelivr.net/gh/iDevMore/tvs-vd1/nfx.mp4'; // Video Link
$Re_skinning_Grp_pause_time = '5'; // Time to Stop Movie

$Re_skinning_Grp_comingsoon = '1';  // 1 to display
$Re_skinning_Grp_related = '1'; // 1 to display


?>

<!-- ================================================================= -->
<!-- ================================================================= -->
<!-- ============ By Mohammed Cha 2023 : Re-skinning GRP ============= -->
<!-- ================================================================= -->
<!-- ================================================================= -->